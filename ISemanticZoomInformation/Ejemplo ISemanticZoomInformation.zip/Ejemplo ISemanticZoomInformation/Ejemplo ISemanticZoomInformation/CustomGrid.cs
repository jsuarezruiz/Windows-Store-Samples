﻿using Windows.UI.Xaml.Controls;

namespace Ejemplo_ISemanticZoomInformation
{
    public class CustomGrid : Grid, ISemanticZoomInformation
    {
        public CustomGrid()
            : base()
        {

        }

        public void CompleteViewChange()
        {
            //throw new System.NotImplementedException();
        }

        public void CompleteViewChangeFrom(SemanticZoomLocation source, SemanticZoomLocation destination)
        {
            //throw new System.NotImplementedException();
        }

        public void CompleteViewChangeTo(SemanticZoomLocation source, SemanticZoomLocation destination)
        {
            //throw new System.NotImplementedException();
        }

        public void InitializeViewChange()
        {
            //throw new System.NotImplementedException();
        }

        public bool IsActiveView
        {
            get;
            set;
        }

        public bool IsZoomedInView
        {
            get;
            set;
        }

        public void MakeVisible(SemanticZoomLocation item)
        {
            //throw new System.NotImplementedException();
        }

        public SemanticZoom SemanticZoomOwner
        {
            get;
            set;
        }

        public void StartViewChangeFrom(SemanticZoomLocation source, SemanticZoomLocation destination)
        {
            //throw new System.NotImplementedException();
        }

        public void StartViewChangeTo(SemanticZoomLocation source, SemanticZoomLocation destination)
        {
            //throw new System.NotImplementedException();
        }
    }
}
