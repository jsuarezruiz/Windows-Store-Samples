﻿using Ejemplo_Contrato_Compartir.Views;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Ejemplo_Contrato_Compartir
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

        }

        private void btnShareText_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Text));
        }

        private void btnShareFormattedText_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(FormattedText));
        }

        private void btnShareImage_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Ejemplo_Contrato_Compartir.Views.Image));
        }

        private void btnShareLink_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Link));
        }
    }
}
