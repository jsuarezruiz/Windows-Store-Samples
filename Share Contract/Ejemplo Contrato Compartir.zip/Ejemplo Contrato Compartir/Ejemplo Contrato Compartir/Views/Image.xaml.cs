﻿using System;
using System.Collections.Generic;
using Windows.ApplicationModel;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234237

namespace Ejemplo_Contrato_Compartir.Views
{
    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class Image : Ejemplo_Contrato_Compartir.Common.LayoutAwarePage
    {
        DataTransferManager _dataTransferManager;

        public Image()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            _dataTransferManager = DataTransferManager.GetForCurrentView();
            _dataTransferManager.DataRequested += _dataTransferManager_DataRequested;
        }

        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            base.OnNavigatingFrom(e);
            _dataTransferManager.DataRequested -= _dataTransferManager_DataRequested;
        }

        async void _dataTransferManager_DataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            string textTitle = "Título a compartir";
            string textSource = "Contenido a compartir. En este ejemplo, una imagen.";
     
            DataPackage data = args.Request.Data;
            data.Properties.Title = textTitle;
            data.Properties.Description = textSource;

            DataRequestDeferral waiter = args.Request.GetDeferral();

            StorageFile image = await Package.Current.InstalledLocation.GetFileAsync("Assets\\Logo.png");
            data.Properties.Thumbnail = RandomAccessStreamReference.CreateFromFile(image);
            data.SetBitmap(RandomAccessStreamReference.CreateFromFile(image));

            List<IStorageItem> files = new List<IStorageItem>();
            files.Add(image);
            data.SetStorageItems(files);

            waiter.Complete();
        }
    }
}
