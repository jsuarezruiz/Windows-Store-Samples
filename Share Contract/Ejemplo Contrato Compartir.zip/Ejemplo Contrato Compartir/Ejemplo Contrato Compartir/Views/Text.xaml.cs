﻿using System;
using System.Collections.Generic;
using Windows.ApplicationModel.DataTransfer;    //DataTransferManager
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234237

namespace Ejemplo_Contrato_Compartir.Views
{
    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class Text : Ejemplo_Contrato_Compartir.Common.LayoutAwarePage
    {
        DataTransferManager _dataTransferManager;

        public Text()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            _dataTransferManager = DataTransferManager.GetForCurrentView();
            _dataTransferManager.DataRequested += _dataTransferManager_DataRequested;
        }

        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            base.OnNavigatingFrom(e);
            _dataTransferManager.DataRequested -= _dataTransferManager_DataRequested;
        }

        void _dataTransferManager_DataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            string textTitle = "Título a compartir";
            string textSource = "Contenido a compartir. En este ejemplo, texto plano, sin formato.";
     
            DataPackage data = args.Request.Data;
            data.Properties.Title = textTitle;
            data.SetText(textSource);
        }
    }
}
